"use strict";

{
	const PLUGIN_CLASS = SDK.Plugins.Rex_Firebase_Authentication;

	PLUGIN_CLASS.Type = class Rex_Firebase_AuthenticationType extends SDK.ITypeBase
	{
		constructor(sdkPlugin, iObjectType)
		{
			super(sdkPlugin, iObjectType);
		}
	};
}
